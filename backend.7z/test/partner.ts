import {
  Model,
  Table,
  Column,
  DataType,
  Index,
  Sequelize,
  ForeignKey,
} from 'sequelize-typescript';

export interface partnerAttributes {
  id: number;
  name: string;
  url?: string;
}

@Table({ tableName: 'partner', timestamps: false })
export class partner
  extends Model<partnerAttributes, partnerAttributes>
  implements partnerAttributes
{
  @Column({ primaryKey: true, type: DataType.INTEGER })
  @Index({ name: 'PRIMARY', using: 'BTREE', order: 'ASC', unique: true })
  id!: number;

  @Column({ type: DataType.STRING(30) })
  name!: string;

  @Column({ allowNull: true, type: DataType.STRING })
  url?: string;
}
