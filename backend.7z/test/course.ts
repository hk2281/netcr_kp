import {
  Model,
  Table,
  Column,
  DataType,
  Index,
  Sequelize,
  ForeignKey,
} from 'sequelize-typescript';

export interface courseAttributes {
  id: number;
  name: string;
  position: number;
  description: string;
  address: string;
  room: number;
  courseWork: number;
  time: Date;
}

@Table({ tableName: 'course', timestamps: false })
export class course
  extends Model<courseAttributes, courseAttributes>
  implements courseAttributes
{
  @Column({ primaryKey: true, type: DataType.INTEGER })
  @Index({ name: 'PRIMARY', using: 'BTREE', order: 'ASC', unique: true })
  id!: number;

  @Column({ type: DataType.STRING(30) })
  name!: string;

  @Column({ type: DataType.INTEGER })
  @Index({ name: 'position', using: 'BTREE', order: 'ASC', unique: false })
  position!: number;

  @Column({ type: DataType.STRING })
  description!: string;

  @Column({ type: DataType.STRING(30) })
  address!: string;

  @Column({ type: DataType.INTEGER })
  room!: number;

  @Column({ field: 'course_work', type: DataType.TINYINT })
  courseWork!: number;

  @Column({ type: DataType.DATE })
  time!: Date;
}
