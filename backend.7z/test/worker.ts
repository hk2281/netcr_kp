import {
  Model,
  Table,
  Column,
  DataType,
  Index,
  Sequelize,
  ForeignKey,
} from '';

export interface workerAttributes {
  id: number;
  firstname: string;
  lastname: string;
  grade?: string;
  address?: string;
  phone?: string;
  position: number;
}

@Table({ tableName: 'worker', timestamps: false })
export class worker
  extends Model<workerAttributes, workerAttributes>
  implements workerAttributes
{
  @Column({ primaryKey: true, type: DataType.INTEGER })
  @Index({ name: 'PRIMARY', using: 'BTREE', order: 'ASC', unique: true })
  id!: number;

  @Column({ type: DataType.STRING(30) })
  firstname!: string;

  @Column({ type: DataType.STRING(30) })
  lastname!: string;

  @Column({ allowNull: true, type: DataType.STRING(30) })
  grade?: string;

  @Column({ allowNull: true, type: DataType.STRING(30) })
  address?: string;

  @Column({ allowNull: true, type: DataType.STRING(12) })
  phone?: string;

  @Column({ type: DataType.INTEGER })
  @Index({ name: 'position', using: 'BTREE', order: 'ASC', unique: false })
  position!: number;
}
