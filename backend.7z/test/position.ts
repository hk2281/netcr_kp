import {
  Model,
  Table,
  Column,
  DataType,
  Index,
  Sequelize,
  ForeignKey,
} from 'sequelize-typescript';

export interface positionAttributes {
  id: number;
  name: string;
  rate?: number;
  lesson: number;
}

@Table({ tableName: 'position', timestamps: false })
export class position
  extends Model<positionAttributes, positionAttributes>
  implements positionAttributes
{
  @Column({ primaryKey: true, type: DataType.INTEGER })
  @Index({ name: 'PRIMARY', using: 'BTREE', order: 'ASC', unique: true })
  id!: number;

  @Column({ type: DataType.STRING(30) })
  @Index({ name: 'position', using: 'BTREE', order: 'ASC', unique: false })
  name!: string;

  @Column({ allowNull: true, type: DataType.FLOAT(12) })
  rate?: number;

  @Column({ type: DataType.INTEGER })
  lesson!: number;
}
