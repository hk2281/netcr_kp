import {
  Model,
  Table,
  Column,
  DataType,
  Index,
  Sequelize,
  ForeignKey,
} from 'sequelize-typescript';

export interface courseListAttributes {
  id: number;
  name: string;
  courseId?: number;
  partnerId?: number;
}

@Table({ tableName: 'course_list', timestamps: false })
export class courseList
  extends Model<courseListAttributes, courseListAttributes>
  implements courseListAttributes
{
  @Column({ primaryKey: true, type: DataType.INTEGER })
  @Index({ name: 'PRIMARY', using: 'BTREE', order: 'ASC', unique: true })
  id!: number;

  @Column({ type: DataType.STRING(30) })
  name!: string;

  @Column({ field: 'course_id', allowNull: true, type: DataType.INTEGER })
  @Index({ name: 'course_id', using: 'BTREE', order: 'ASC', unique: false })
  courseId?: number;

  @Column({ field: 'partner_id', allowNull: true, type: DataType.INTEGER })
  @Index({ name: 'partner_id', using: 'BTREE', order: 'ASC', unique: false })
  partnerId?: number;
}
