import { Column, Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from "typeorm";
import {PositionEntity} from "src/position/position.entity";

@Entity({ name: 'worker' })
export class WorkerEntity {

    @PrimaryGeneratedColumn()
    id: number;
    @Column({ type: 'varchar', length: 30, nullable: false })
    firstname: string;
    @Column({ type: 'varchar', length: 30, nullable: false })
    lastname: string;
    @Column({ type: 'varchar', length: 30, nullable: true })
    grade: string;
    @Column({ type: 'varchar', length: 30, nullable: true })
    address: string;
    @Column({ type: 'varchar', length: 12, nullable: false })
    phone: string;


    @ManyToOne(type => PositionEntity, position => position.worker,
        {nullable: false,eager: true}
    )
    position?: PositionEntity[];


}
