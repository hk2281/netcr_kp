import { PositionEntity } from "src/position/position.entity";

export class WorkerDto {
  firstname?: string;
  lastname?: string;
  grade?: string;
  address?: string;
  phone?: string;
  position?: PositionEntity[];
}