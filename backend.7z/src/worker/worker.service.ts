import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { WorkerEntity } from './worker.entity';
import { WorkerRepository } from './worker.repository';
import { WorkerDto } from './dto/worker.dto';

@Injectable()
export class WorkerService {
  constructor(
    @InjectRepository(WorkerEntity)
    private workerRepository: WorkerRepository,
  ) {}
  async getAll(): Promise<WorkerEntity[]> {
    const list = await this.workerRepository.find();
    if (!list.length) {
      throw new NotFoundException({ message: 'list is empty' });
    }
    return list;
  }
  async findById(id: number): Promise<WorkerEntity> {
    const worker = await this.workerRepository.findOneBy({
      id: id,
    });
    if (!worker) {
      throw new NotFoundException({ message: `worker with ${id} not exist` });
    }
    return worker;
  }
  async findByName(lastname: string): Promise<WorkerEntity> {
    const worker = await this.workerRepository.findOneBy({
      lastname: lastname,
    });
    return worker ? worker : null;
  }

  //   add some find metods

  async create(dto: WorkerDto): Promise<any> {
    const worker = this.workerRepository.create(dto);
    await this.workerRepository.save(worker);
    return { message: `worker ${worker.lastname} save` };
  }
  async update(id: number, dto: WorkerDto): Promise<any> {
    const worker = await this.findById(id);
    dto.lastname
      ? (worker.lastname = dto.lastname)
      : (worker.lastname = worker.lastname);
    dto.firstname
      ? (worker.firstname = dto.firstname)
      : (worker.firstname = worker.firstname);
    dto.address
      ? (worker.address = dto.address)
      : (worker.address = worker.address);
    dto.phone
      ? (worker.phone = dto.phone)
      : (worker.phone = worker.phone);
    dto.grade
      ? (worker.grade = dto.grade)
      : (worker.grade = worker.grade);

    dto.position
      ? (worker.position = dto.position)
      : (worker.position = worker.position);
    await this.workerRepository.save(worker);
    return { message: `worker with ${worker.lastname} and id: ${id} updated` };
  }
  async delete(id: number): Promise<any> {
    const worker = await this.findById(id);
    await this.workerRepository.delete(worker);
    return { message: `worker ${worker.lastname} delete` };
  }
}