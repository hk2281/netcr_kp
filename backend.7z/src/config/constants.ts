export const SERVER_PORT = 'SERVER_PORT'
 
export const BD_HOST= 'BD_HOST'
export const BD_PORT= 'BD_PORT'
export const BD_DATABASE= 'BD_DATABASE'
export const USER='USER'
export const PASSWORD='PASSWORD'
