
import { CourseEntity } from "src/course/course.entity";
import { Column, Entity, ManyToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: 'partner'})
export class PartnerEntity {

    @PrimaryGeneratedColumn()
    id: number
    @Column({ type: 'varchar', length: 30, nullable: false })
    name:string
    @Column({ type: 'varchar', length: 30, nullable: false })
    url: string
    @Column()
    lesson: number

    @ManyToMany(
      () => CourseEntity,
      course => course.partner,
      {onDelete: 'NO ACTION', onUpdate: 'NO ACTION',},
    )
    course?: CourseEntity[];

}