import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { PartnerEntity } from './partner.entity';
import { PositionRepository } from './partner.repository';
import { PartnerDto } from './dto/partner.dto';

@Injectable()
export class PartnerService {
    constructor(
        @InjectRepository(PartnerEntity)
        private partnerRepository: PositionRepository,
      ) {}
      async getAll(): Promise<PartnerEntity[]> {
        const list = await this.partnerRepository.find();
        if (!list.length) {
          throw new NotFoundException({ message: 'list is empty' });
        }
        return list;
      }
      async findById(id: number): Promise<PartnerEntity> {
        const partner = await this.partnerRepository.findOneBy({
          id: id,
        });
        if (!partner) {
          throw new NotFoundException({ message: `partner with ${id} not exist` });
        }
        return partner;
      }
      async findByName(name: string): Promise<PartnerEntity> {
        const partner = await this.partnerRepository.findOneBy({
          name: name,
        });
        return partner ? partner : null;
      }
    
      //   add some find metods
    
      async create(dto: PartnerDto): Promise<any> {
        const partner = this.partnerRepository.create(dto);
        await this.partnerRepository.save(partner);
        return { message: `partner ${partner.name} save` };
      }
      async update(id: number, dto: PartnerDto): Promise<any> {
        const partner = await this.findById(id);
        dto.name
          ? (partner.name = dto.name)
          : (partner.name = partner.name);
        dto.url
          ? (partner.url = dto.url)
          : (partner.url = partner.url);
        await this.partnerRepository.save(partner);
        return { message: `partner with ${partner.name} and id: ${id} updated` };
      }
      async delete(id: number): Promise<any> {
        const partner = await this.findById(id);
        await this.partnerRepository.delete(partner);
        return { message: `partner ${partner.name} delete` };
      }
}
