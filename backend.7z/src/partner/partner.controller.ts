
import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
  } from '@nestjs/common';
import { PositionService } from 'src/position/position.service';
import { PartnerService } from './partner.service';
import { PartnerDto } from './dto/partner.dto';
@Controller('partner')
export class PartnerController {
    constructor(private readonly partnerServise: PartnerService) {}

    @Get()
    async getAll() {
      return await this.partnerServise.getAll();
    }
    @Get(':id')
    async getOne(@Param('id', ParseIntPipe) id: number) {
      return await this.partnerServise.findById(id);
    }
    @Post()
    async create(@Body() dto: PartnerDto) {
      return await this.partnerServise.create(dto);
    }
    @Put(':id')
    async update(@Param('id', ParseIntPipe) id: number, @Body() dto: PartnerDto) {
      return await this.partnerServise.update(id, dto);
    }
    @Delete(':id')
    async delete(@Param('id', ParseIntPipe) id: number) {
      return await this.partnerServise.delete(id);
    }

}
