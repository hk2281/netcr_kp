import { Module } from '@nestjs/common';
import { PartnerService } from './partner.service';
import { PartnerController } from './partner.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PartnerEntity } from './partner.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PartnerEntity])],
  providers: [PartnerService],
  controllers: [PartnerController]
})
export class PartnerModule {}
