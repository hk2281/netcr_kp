import { WorkerEntity } from "src/worker/worker.entity";

export class PartnerDto {
    name?: string;
    url?: string;
}