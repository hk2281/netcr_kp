import { EntityRepository, Repository } from 'typeorm';
import { PartnerEntity } from './partner.entity';


@EntityRepository(PartnerEntity)
export class PositionRepository extends Repository<PartnerEntity> {}