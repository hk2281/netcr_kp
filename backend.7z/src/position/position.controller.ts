
import { WorkerService } from 'src/worker/worker.service';
import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
  } from '@nestjs/common';
import { WorkerDto } from 'src/worker/dto/worker.dto';
import { PositionService } from './position.service';
import { PositionDto } from './dto/position.dto';

@Controller('position')
export class PositionController {
    constructor(private readonly workerServise: PositionService) {}

    @Get()
    async getAll() {
      return await this.workerServise.getAll();
    }
    @Get(':id')
    async getOne(@Param('id', ParseIntPipe) id: number) {
      return await this.workerServise.findById(id);
    }
    @Post()
    async create(@Body() dto: PositionDto) {
      return await this.workerServise.create(dto);
    }
    @Put(':id')
    async update(@Param('id', ParseIntPipe) id: number, @Body() dto: PositionDto) {
      return await this.workerServise.update(id, dto);
    }
    @Delete(':id')
    async delete(@Param('id', ParseIntPipe) id: number) {
      return await this.workerServise.delete(id);
    }

}
