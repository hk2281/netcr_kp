import { CourseEntity } from "src/course/course.entity";
import { WorkerEntity } from "src/worker/worker.entity";

export class PositionDto {
    name?: string;
    rate?: number;
    course?: CourseEntity;
  }