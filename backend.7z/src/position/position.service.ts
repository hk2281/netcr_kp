import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { PositionRepository } from './position.repository';
import { PositionEntity } from './position.entity';
import { PositionDto } from './dto/position.dto';

@Injectable()
export class PositionService {
    constructor(
        @InjectRepository(PositionEntity)
        private positionRepository: PositionRepository,
      ) {}
      async getAll(): Promise<PositionEntity[]> {
        const list = await this.positionRepository.find();
        if (!list.length) {
          throw new NotFoundException({ message: 'list is empty' });
        }
        return list;
      }
      async findById(id: number): Promise<PositionEntity> {
        const position = await this.positionRepository.findOneBy({
          id: id,
        });
        if (!position) {
          throw new NotFoundException({ message: `position with ${id} not exist` });
        }
        return position;
      }
      async findByName(name: string): Promise<PositionEntity> {
        const position = await this.positionRepository.findOneBy({
          name: name,
        });
        return position ? position : null;
      }
    
      //   add some find metods
    
      async create(dto: PositionDto): Promise<any> {
        const position = this.positionRepository.create(dto);
        await this.positionRepository.save(position);
        return { message: `position ${position.name} save` };
      }
      async update(id: number, dto: PositionDto): Promise<any> {
        const position = await this.findById(id);
        dto.name
          ? (position.name = dto.name)
          : (position.name = position.name);
        dto.rate
          ? (position.rate = dto.rate)
          : (position.rate = position.rate);
        dto.course
          ? (position.course = dto.course)
          : (position.course = position.course);
        await this.positionRepository.save(position);
        return { message: `position with ${position.name} and id: ${id} updated` };
      }
      async delete(id: number): Promise<any> {
        const position = await this.findById(id);
        await this.positionRepository.delete(position);
        return { message: `position ${position.name} delete` };
      }
}
