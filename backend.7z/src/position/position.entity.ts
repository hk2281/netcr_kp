
import { CourseEntity } from "src/course/course.entity";
import { WorkerEntity } from "src/worker/worker.entity";
import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: 'position'})
export class PositionEntity {

    @PrimaryGeneratedColumn()
    id: number
    @Column({ type: 'varchar', length: 30, nullable: false })
    name:string
    @Column()
    rate: number

    @ManyToOne(type => CourseEntity, course => course.position,
      {nullable: false,eager: true}
      )
    course?: CourseEntity;

    @OneToMany(type => WorkerEntity, worker=>worker.position,)
    worker?:WorkerEntity;


}