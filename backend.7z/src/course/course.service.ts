import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CourseEntity } from './course.entity';
import { CourseRepository } from './course.repository';
import { CourseDto } from './dto/course.dto';

@Injectable()
export class CourseService {
    constructor(
        @InjectRepository(CourseEntity)
        private courseRepository: CourseRepository,
      ) {}
      async getAll(): Promise<CourseEntity[]> {
        const list = await this.courseRepository.find();
        if (!list.length) {
          throw new NotFoundException({ message: 'list is empty' });
        }
        return list;
      }
      async findById(id: number): Promise<CourseEntity> {
        const course = await this.courseRepository.findOneBy({
          id: id,
        });
        if (!course) {
          throw new NotFoundException({ message: `course with ${id} not exist` });
        }
        return course;
      }
      async findByName(name: string): Promise<CourseEntity> {
        const course = await this.courseRepository.findOneBy({
          name: name,
        });
        return course ? course : null;
      }
    
      //   add some find metods
    
      async create(dto: CourseDto): Promise<any> {
        const course = this.courseRepository.create(dto);
        await this.courseRepository.save(course);
        return { message: `course ${course.name} save` };
      }
      async update(id: number, dto: CourseDto): Promise<any> {
        const course = await this.findById(id);
        dto.name
          ? (course.name = dto.name)
          : (course.name = course.name);
        dto.description
          ? (course.description = dto.description)
          : (course.description = course.description);
        dto.address
          ? (course.address = dto.address)
          : (course.address = course.address);
        dto.room
        ? (course.room = dto.room)
        : (course.room = course.room);
        dto.time
        ? (course.time = dto.time)
        : (course.time = course.time);

        // dto.position
        // ? (course.position = dto.position)
        // : (course.position = course.position);
        await this.courseRepository.save(course);
        return { message: `course with ${course.name} and id: ${id} updated` };
      }
      async delete(id: number): Promise<any> {
        const course = await this.findById(id);
        await this.courseRepository.delete(course);
        return { message: `course ${course.name} delete` };
      }
}
