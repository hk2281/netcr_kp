
import { CourselistEntity } from "src/courselist/courselist.entity";
import { PartnerEntity } from "src/partner/partner.entity";
import { PositionEntity } from "src/position/position.entity";
import { WorkerEntity } from "src/worker/worker.entity";
import { Column, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: 'course'})
export class CourseEntity {

    @PrimaryGeneratedColumn()
    id: number
    @Column({ type: 'varchar', length: 30, nullable: false })
    name:string
    @Column({ type: 'text', nullable: true })
    description:string
    @Column()
    address: string;
    @Column()
    room: number;
    @Column()
    course_work: number;
    @Column({ type: 'varchar', length: 30, nullable: false })
    time: string;

    @OneToMany(type => PositionEntity, position=>position.course)
    position:PositionEntity[];

    @ManyToMany(
        () => PartnerEntity, 
        partner => partner.course, //optional
        {onDelete: 'SET NULL', onUpdate: 'CASCADE', eager: true})
        @JoinTable({
          name: 'course_list',
          joinColumn: {
            name: 'course_id',

          },
          inverseJoinColumn: {
            name: 'partner_id',

          },
        })
        partner?: PartnerEntity[];


}