import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
  } from '@nestjs/common';
import { PositionService } from 'src/position/position.service';

import { CourseService } from './course.service';
import { CourseDto } from './dto/course.dto';
@Controller('course')
export class CourseController {
    constructor(private readonly courseServise: CourseService) {}

    @Get()
    async getAll() {
      return await this.courseServise.getAll();
    }
    @Get(':id')
    async getOne(@Param('id', ParseIntPipe) id: number) {
      return await this.courseServise.findById(id);
    }
    @Post()
    async create(@Body() dto: CourseDto) {
      return await this.courseServise.create(dto);
    }
    @Put(':id')
    async update(@Param('id', ParseIntPipe) id: number, @Body() dto: CourseDto) {
      return await this.courseServise.update(id, dto);
    }
    @Delete(':id')
    async delete(@Param('id', ParseIntPipe) id: number) {
      return await this.courseServise.delete(id);
    }
}