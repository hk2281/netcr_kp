import { CourseEntity } from "src/course/course.entity";
import { CourselistEntity } from "src/courselist/courselist.entity";
import { PartnerEntity } from "src/partner/partner.entity";
import { PositionEntity } from "src/position/position.entity";
import { WorkerEntity } from "src/worker/worker.entity";

export class CourseDto {
    name?: string;
    description?: string;
    address?: string;
    room?: number;
    coursework?: number;
    time?: string;
    courselist?: CourselistEntity;
    position: PositionEntity[];
}