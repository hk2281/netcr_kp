import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService} from '@nestjs/config'
import {TypeOrmModule} from '@nestjs/typeorm'
import {
  BD_DATABASE,
  BD_HOST,
  PASSWORD,
  BD_PORT,
  USER,
} from './config/constants'
import { WorkerModule } from './worker/worker.module';
import { PositionModule } from './position/position.module';
import { PartnerModule } from './partner/partner.module';
import { CourselistModule } from './courselist/courselist.module';
import { CourseModule } from './course/course.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: '.env',
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        type: 'mysql',
        host: configService.get<string>(BD_HOST),
        port: +configService.get<number>(BD_PORT),
        username: configService.get<string>(USER),
        password: configService.get<string>(PASSWORD),
        database: configService.get<string>(BD_DATABASE),
        entities: [__dirname + '/**/*.entity{.ts,.js}'],
        synchronize: false,
        logging: true,
      }),
      inject: [ConfigService],
    }),
    WorkerModule,
    PositionModule,
    PartnerModule,
    CourselistModule,
    CourseModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
