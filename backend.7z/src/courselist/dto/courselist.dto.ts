import { CourseEntity } from "src/course/course.entity";
import { PartnerEntity } from "src/partner/partner.entity";
import { WorkerEntity } from "src/worker/worker.entity";

export class CourselistDto {
    c_id?: number;
    course?: number;
    partnerId?: number;
}