import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CourselistEntity } from './courselist.entity';
import { CourselistRepository } from './courselist.repository';
import { CourselistDto } from './dto/courselist.dto';

@Injectable()
export class CourselistService {
    // constructor(
    //     @InjectRepository(CourselistEntity)
    //     private partnerRepository: CourselistRepository,
    //   ) {}
    //   async getAll(): Promise<CourselistEntity[]> {
    //     const list = await this.partnerRepository.find();
    //     if (!list.length) {
    //       throw new NotFoundException({ message: 'list is empty' });
    //     }
    //     return list;
    //   }
    //   async findByCourseId(id: number): Promise<CourselistEntity> {
    //     const courselist = await this.partnerRepository.findOneBy({
    //       courseId: id,
    //     });
    //     if (!courselist) {
    //       throw new NotFoundException({ message: `courselist with course${id} not exist` });
    //     }
    //     return courselist;
    //   }
      
    //   async findByPartnerId(id: number): Promise<CourselistEntity> {
    //     const courselist = await this.partnerRepository.findOneBy({
    //      partnerId : id
    //     });
    //     if (!courselist) {
    //       throw new NotFoundException({ message: `courselist with partner ${id} not exist` });
    //     }
    //     return courselist;
    //   }
    
    //   //   add some find metods
    
    //   async create(dto: CourselistDto): Promise<any> {
    //     const courselist = this.partnerRepository.create(dto);
    //     await this.partnerRepository.save(courselist);
    //     return { message: `courselist with course id ${courselist.courseId}, and partner id: ${courselist.partnerId} save` };
    //   }
    //   async update(id: number, dto: CourselistDto): Promise<any> {
    //     const courselist = await this.findByCourseId(id);
    //     dto.partnerId
    //       ? (courselist.partnerId = dto.partnerId)
    //       : (courselist.partnerId = courselist.partnerId);
    //     // dto.course
    //       // ? (courselist.course = dto.course)
    //       // : (courselist.course = courselist.course);
    //     await this.partnerRepository.save(courselist);
    //     return { message: `courselist with course id: ${id} updated` };
    //   }
    //   async delete(id: number): Promise<any> {
    //     const courselist = await this.findByPartnerId(id);
    //     await this.partnerRepository.delete(courselist);
    //     return { message: `courselist ${courselist.courseId} delete` };
    //   }
}
