
import { CourseEntity } from "src/course/course.entity";
import { PartnerEntity } from "src/partner/partner.entity";
import { WorkerEntity } from "src/worker/worker.entity";
import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";

@Entity({name: 'course_list'})
export class CourselistEntity {

    @PrimaryColumn({ name: 'partner_id' })
    partnerId: number;
  
    @PrimaryColumn({ name: 'course_id' })
    courseId: number;
  
    @ManyToOne(
      () => CourseEntity,
      course => course.partner,
      {onDelete: 'NO ACTION', onUpdate: 'NO ACTION'}
    )
    @JoinColumn([{ name: 'course_id', referencedColumnName: 'id' }])
    course: CourseEntity[];
  
    @ManyToOne(
      () => PartnerEntity,
       partner => partner.course,
      {onDelete: 'NO ACTION', onUpdate: 'NO ACTION'}
    )
    @JoinColumn([{ name: 'partner_id', referencedColumnName: 'id' }])
    partner: PartnerEntity[];

}