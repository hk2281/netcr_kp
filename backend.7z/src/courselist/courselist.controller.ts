
import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
  } from '@nestjs/common';
import { PositionService } from 'src/position/position.service';

import { CourselistService } from './courselist.service';
import { CourselistDto } from './dto/courselist.dto';
@Controller('courselist')
export class CourselistController {
    // constructor(private readonly courselistServise: CourselistService) {}

    // @Get()
    // async getAll() {
    //   return await this.courselistServise.getAll();
    // }
    // @Get(':id')
    // async getOne(@Param('id', ParseIntPipe) id: number) {
    //   return await this.courselistServise.findById(id);
    // }
    // @Post()
    // async create(@Body() dto: CourselistDto) {
    //   return await this.courselistServise.create(dto);
    // }
    // @Put(':id')
    // async update(@Param('id', ParseIntPipe) id: number, @Body() dto: CourselistDto) {
    //   return await this.courselistServise.update(id, dto);
    // }
    // @Delete('id')
    // async delete(@Param('id', ParseIntPipe) id: number) {
    //   return await this.courselistServise.delete(id);
    // }

}
