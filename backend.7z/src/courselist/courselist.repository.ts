import { EntityRepository, Repository } from 'typeorm';

import { CourselistEntity } from './courselist.entity';


@EntityRepository(CourselistEntity)
export class CourselistRepository extends Repository<CourselistEntity> {}