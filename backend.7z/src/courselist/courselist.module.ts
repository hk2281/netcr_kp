import { Module } from '@nestjs/common';
import { CourselistService } from './courselist.service';
import { CourselistController } from './courselist.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CourselistEntity } from './courselist.entity';

@Module({
  imports: [TypeOrmModule.forFeature([CourselistEntity])],
  providers: [CourselistService],
  controllers: [CourselistController]
})
export class CourselistModule {}
